#include <stdio.h>
#include <stdlib.h>
#include <vector>

// Include GLEW
#include <glew.h>

// Include GLFW
#include <glfw3.h>
GLFWwindow* window;

// Include GLM
#include <glm.hpp>
#include <gtc/matrix_transform.hpp>
using namespace glm;

#include <common/shader.hpp>
#include <common/controls.hpp>
#include <common/objloader.hpp>

// Velocidade de movimento da nave
const float movementSpeed = 5.0f;

int main(void)
{
    // Inicializa��o do GLFW
    if (!glfwInit()) {
        fprintf(stderr, "Falha ao inicializar o GLFW\n");
        return -1;
    }

    glfwWindowHint(GLFW_SAMPLES, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    // Criar a janela
    window = glfwCreateWindow(1024, 768, "Star Wars da Wish", NULL, NULL);
    if (window == NULL) {
        fprintf(stderr, "Falha ao abrir a janela GLFW.\n");
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);

    // Inicializar o GLEW
    glewExperimental = true;
    if (glewInit() != GLEW_OK) {
        fprintf(stderr, "Falha ao inicializar o GLEW\n");
        glfwTerminate();
        return -1;
    }

    // Configura��es de entrada e contexto
    glfwSetInputMode(window, GLFW_STICKY_KEYS, GL_TRUE);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    glfwSetCursorPos(window, 1024 / 2, 768 / 2);

    // Configura��es de OpenGL
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);
    glEnable(GL_CULL_FACE);

    // Configura��o do Vertex Array Object
    GLuint VertexArrayID;
    glGenVertexArrays(1, &VertexArrayID);
    glBindVertexArray(VertexArrayID);

    // Carregar e compilar shaders
    GLuint programID = LoadShaders("TransformVertexShader.vertexshader", "TextureFragmentShader.fragmentshader");
    GLuint MatrixID = glGetUniformLocation(programID, "MVP");
    GLuint ModelMatrixID = glGetUniformLocation(programID, "ModelMatrix");
    GLuint ViewMatrixID = glGetUniformLocation(programID, "ViewMatrix");

    // Carregar arquivos OBJ para tr�s objetos
    std::vector<glm::vec3> vertices[3];
    std::vector<glm::vec2> uvs[3];
    std::vector<glm::vec3> normals[3];
    bool res1 = loadOBJ("C:/Users/gl449/source/repos/nave4.obj", vertices[0], uvs[0], normals[0]);
    bool res2 = loadOBJ("C:/Users/gl449/source/repos/Iluminacao/hangar1.obj", vertices[1], uvs[1], normals[1]);
    bool res3 = loadOBJ("C:/Users/gl449/source/repos/Iluminacao/hangar1.obj", vertices[2], uvs[2], normals[2]);

    // Buffers para os objetos
    GLuint vertexbuffer[3];
    GLuint uvbuffer[3];

    for (int i = 0; i < 3; ++i) {
        glGenBuffers(1, &vertexbuffer[i]);
        glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer[i]);
        glBufferData(GL_ARRAY_BUFFER, vertices[i].size() * sizeof(glm::vec3), &vertices[i][0], GL_STATIC_DRAW);

        glGenBuffers(1, &uvbuffer[i]);
        glBindBuffer(GL_ARRAY_BUFFER, uvbuffer[i]);
        glBufferData(GL_ARRAY_BUFFER, uvs[i].size() * sizeof(glm::vec2), &uvs[i][0], GL_STATIC_DRAW);
    }

    // Posi��es iniciais dos objetos
    glm::vec3 objectPositions[3] = {
        glm::vec3(-20, 0, 10), // Nave
        glm::vec3(-20, 0, 10), // Hangar 1
        glm::vec3(20, 0, 10)   // Hangar 2
    };

    // Definir posi��o da luz, cor da luz, cor do objeto, e brilho
    glm::vec3 lightPos(0.0f, 10.0f, 0.0f); // Posi��o da luz
    glm::vec3 lightColor(1.0f, 1.0f, 1.0f); // Cor da luz (branca)
    glm::vec3 objectColor(1.0f, 0.5f, 0.31f); // Cor do objeto (laranja)
    float shininess = 32.0f; // Brilho do material

    // Loop principal
    do {
        // Limpar a tela
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Usar os shaders
        glUseProgram(programID);

        // Atualizar matrizes da c�mera
        computeMatricesFromInputs();
        glm::mat4 ProjectionMatrix = getProjectionMatrix();
        glm::mat4 ViewMatrix = getViewMatrix();

        // Passar as vari�veis de ilumina��o para o shader
        glUniform3fv(glGetUniformLocation(programID, "lightPos"), 1, &lightPos[0]);
        glUniform3fv(glGetUniformLocation(programID, "viewPos"), 1, &objectPositions[0][0]); // Posi��o da c�mera
        glUniform3fv(glGetUniformLocation(programID, "lightColor"), 1, &lightColor[0]);
        glUniform3fv(glGetUniformLocation(programID, "objectColor"), 1, &objectColor[0]);
        glUniform1f(glGetUniformLocation(programID, "shininess"), shininess);

        // Detec��o de teclas para mover a nave
        if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
            objectPositions[0].z -= movementSpeed * 0.01f; // Movimento para frente
        }
        if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
            objectPositions[0].z += movementSpeed * 0.01f; // Movimento para tr�s
        }
        if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
            objectPositions[0].x -= movementSpeed * 0.01f; // Movimento para a esquerda
        }
        if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
            objectPositions[0].x += movementSpeed * 0.01f; // Movimento para a direita
        }

        // Renderizar cada objeto
        for (int i = 0; i < 3; ++i) {
            glm::mat4 ModelMatrix = glm::translate(glm::mat4(1.0f), objectPositions[i]);

            if (i == 1 || i == 2) {
                ModelMatrix = glm::scale(ModelMatrix, glm::vec3(0.09f, 0.09f, 0.09f));
            }

            if (i == 2) {
                ModelMatrix = glm::scale(ModelMatrix, glm::vec3(-1.0f, 1.0f, 1.0f));  // Espelhamento no eixo X
            }

            glm::mat4 MVP = ProjectionMatrix * ViewMatrix * ModelMatrix;

			glUniformMatrix4fv(MatrixID, 1, GL_FALSE, &MVP[0][0]); 
			glUniformMatrix4fv(ModelMatrixID, 1, GL_FALSE, &ModelMatrix[0][0]);
			glUniformMatrix4fv(ViewMatrixID, 1, GL_FALSE, &ViewMatrix[0][0]); 

            // Configurar os buffers
            glEnableVertexAttribArray(0);
            glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer[i]);
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);

            glEnableVertexAttribArray(1);
            glBindBuffer(GL_ARRAY_BUFFER, uvbuffer[i]);
            glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);

            // Desenhar o objeto
            glDrawArrays(GL_TRIANGLES, 0, vertices[i].size());

            glDisableVertexAttribArray(0);
            glDisableVertexAttribArray(1);
        }

        glfwSwapBuffers(window);
        glfwPollEvents();

    } while (glfwGetKey(window, GLFW_KEY_ESCAPE) != GLFW_PRESS &&
        glfwWindowShouldClose(window) == 0);

    // Finalizar
    glfwTerminate();
    return 0;
}
